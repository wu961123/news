var figure = {
    "data": [
        {
            "type": "surface",
            "xsrc": "wu961123:0:df3dae",
            "x": [
                8.83,
                8.92,
                8.8,
                8.91,
                8.97,
                9.2
            ],
            "ysrc": "wu961123:0:4bf57e",
            "y": [
                8.89,
                8.93,
                8.82,
                8.95,
                8.97,
                9.23
            ],
            "zsrc": "wu961123:0:df3dae,4bf57e,60b060,ef10bd,0156f4,b0a344,a9d8fe,3d6372,79e33b,a7f931,7bf213,604919,d9489e,4ab135,181400",
            "z": [
                [
                    8.83,
                    8.89,
                    8.81,
                    8.87,
                    8.9,
                    8.87,
                    8.89,
                    8.94,
                    8.85,
                    8.94,
                    8.96,
                    8.92,
                    8.84,
                    8.9,
                    8.82
                ],
                [
                    8.92,
                    8.93,
                    8.91,
                    8.79,
                    8.85,
                    8.79,
                    8.9,
                    8.94,
                    8.92,
                    8.79,
                    8.88,
                    8.81,
                    8.9,
                    8.95,
                    8.92
                ],
                [
                    8.8,
                    8.82,
                    8.78,
                    8.91,
                    8.94,
                    8.92,
                    8.75,
                    8.78,
                    8.77,
                    8.91,
                    8.95,
                    8.92,
                    8.8,
                    8.8,
                    8.77
                ],
                [
                    8.91,
                    8.95,
                    8.94,
                    8.74,
                    8.81,
                    8.76,
                    8.93,
                    8.98,
                    8.99,
                    8.89,
                    8.99,
                    8.92,
                    9.1,
                    9.13,
                    9.11
                ],
                [
                    8.97,
                    8.97,
                    8.91,
                    9.09,
                    9.11,
                    9.11,
                    9.04,
                    9.08,
                    9.05,
                    9.25,
                    9.28,
                    9.27,
                    9,
                    9.01,
                    9
                ],
                [
                    9.2,
                    9.23,
                    9.2,
                    8.99,
                    8.99,
                    8.98,
                    9.18,
                    9.2,
                    9.19,
                    8.93,
                    8.97,
                    8.97,
                    9.18,
                    9.2,
                    9.18
                ]
            ],
            "colorbar": {
                "title": {
                    "text": "z<br>z2<br>z3"
                },
                "ticklen": 2
            },
            "showscale": false,
            "colorscale": [
                [
                    "0",
                    "rgba(68,1,84,1)"
                ],
                [
                    "0.0236220472440947",
                    "rgba(69,11,91,1)"
                ],
                [
                    "0.0511811023622043",
                    "rgba(71,22,100,1)"
                ],
                [
                    "0.0669291338582677",
                    "rgba(71,27,105,1)"
                ],
                [
                    "0.074803149606299",
                    "rgba(71,29,108,1)"
                ],
                [
                    "0.0905511811023624",
                    "rgba(72,34,113,1)"
                ],
                [
                    "0.103346456692913",
                    "rgba(72,38,117,1)"
                ],
                [
                    "0.173228346456693",
                    "rgba(68,60,129,1)"
                ],
                [
                    "0.333333333333332",
                    "rgba(49,104,142,1)"
                ],
                [
                    "0.41732283464567",
                    "rgba(42,124,142,1)"
                ],
                [
                    "0.444881889763779",
                    "rgba(38,130,142,1)"
                ],
                [
                    "0.460629921259843",
                    "rgba(38,134,141,1)"
                ],
                [
                    "0.468503937007874",
                    "rgba(38,136,141,1)"
                ],
                [
                    "0.483103674540682",
                    "rgba(37,140,140,1)"
                ],
                [
                    "0.496062992125984",
                    "rgba(37,143,140,1)"
                ],
                [
                    "0.566929133858268",
                    "rgba(34,161,135,1)"
                ],
                [
                    "0.666666666666663",
                    "rgba(53,183,121,1)"
                ],
                [
                    "0.811023622047245",
                    "rgba(133,210,78,1)"
                ],
                [
                    "0.836614173228347",
                    "rgba(149,214,69,1)"
                ],
                [
                    "0.854330708661418",
                    "rgba(160,217,61,1)"
                ],
                [
                    "0.862204724409449",
                    "rgba(165,218,58,1)"
                ],
                [
                    "0.875492125984253",
                    "rgba(172,220,51,1)"
                ],
                [
                    "0.889763779527559",
                    "rgba(181,222,44,1)"
                ],
                [
                    "0.956528871391076",
                    "rgba(225,228,40,1)"
                ],
                [
                    "1",
                    "rgba(253,231,37,1)"
                ]
            ]
        }
    ],
    "layout": {
        "scene": {
            "zaxis": {
                "title": {
                    "text": "z"
                }
            },
            "camera": {
                "up": {
                    "x": 0,
                    "y": 0,
                    "z": 1
                },
                "eye": {
                    "x": -2.565990362325871,
                    "y": -0.004802415463182829,
                    "z": -0.13856857113291363
                },
                "center": {
                    "x": 0,
                    "y": 0,
                    "z": 0
                },
                "projection": {
                    "type": "perspective"
                }
            },
            "aspectmode": "auto",
            "aspectratio": {
                "x": 0.8973890970391378,
                "y": 0.9198238244651199,
                "z": 1.2114752810028386
            }
        },
        "xaxis": {
            "domain": [
                0,
                1
            ]
        },
        "yaxis": {
            "domain": [
                0,
                1
            ]
        },
        "margin": {
            "b": 40,
            "l": 60,
            "r": 10,
            "t": 25
        },
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        }
    },
    "frames": []
}